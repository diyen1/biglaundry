import { Component, OnInit } from '@angular/core';
import {DmWoocommerceCartService} from '../../modules/woocomerce/services/dm-woocommerce-cart.service';
import {DmWoocommerceOrdersService} from '../../modules/woocomerce/services/dm-woocommerce-orders.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {DmWoocommercePaymentService} from '../../modules/woocomerce/services/dm-woocommerce-payment.service';

@Component({
  selector: 'app-checkout-step4',
  templateUrl: './checkout-step4.component.html',
  styleUrls: ['./checkout-step4.component.scss']
})
export class CheckoutStep4Component implements OnInit {

  form: FormGroup;
  paymentMethod: FormControl;
  formIsValid = false;

  paymentMethods: any = [
    {
      name: 'Cash on delivery',
      phoneKey: 'codPhone',
      value: 'cod',
      isValid: false,
    },
    {
      name: 'Momo',
      phoneKey: 'momoPhone',
      value: 'momo',
      isValid: false,
    },
    {
      name: 'Om',
      phoneKey: 'omPhone',
      value: 'om',
      isValid: false,
    },
  ]; // TODO create a payment method object
  controlsConfig = {};
  error = null;

  constructor(
    public woocommerceCartService: DmWoocommerceCartService,
    private orderService: DmWoocommerceOrdersService,
    private paymentService: DmWoocommercePaymentService,
    private fb: FormBuilder,
  ) { }

  ngOnInit() {
    // this.paymentMethod = new FormControl('momo', []);
    this.controlsConfig['paymentMethod'] = ['cod'];
    // this.controlsConfig['codPhone'] = [''];
    // this.controlsConfig['momoPhone'] = [''];
    // this.controlsConfig['omPhone'] = [''];

    for (let i = 0; i < this.paymentMethods.length; i++) {
      const paymentMethod = this.paymentMethods[i];
      this.controlsConfig[paymentMethod.phoneKey] = [''];
    }

    this.form = this.fb.group(this.controlsConfig);
  }

  updateFormValidity(event, paymentMethod) {
    for (let i = 0; i < this.paymentMethods.length; i++) {
      if (paymentMethod === this.paymentMethods[i].value) {
        this.paymentMethods[i].isValid = event;
        break;
      }
    }
    this.formIsValid = event;
  }

  changePaymentmenthod() {
    const paymentMethod = this.form.get('paymentMethod').value;
    for (let i = 0; i < this.paymentMethods.length; i++) {
      if (paymentMethod === this.paymentMethods[i].value) {
        this.formIsValid = this.paymentMethods[i].isValid;
        break;
      }
    }
  }


  order(formValue) {
    this.orderService.updatePayment(formValue);

    this.paymentService.handlePayment(formValue).subscribe((haspaid) => {
      console.log(haspaid);
      if (haspaid) {
        this.orderService.addOrder().subscribe((res) => {
          console.log('order', res);
        });
        this.error = null;
      } else {
        // TODO handle all the errors
        this.error = 'Failed to process payment';
      }
    });
  }
}
